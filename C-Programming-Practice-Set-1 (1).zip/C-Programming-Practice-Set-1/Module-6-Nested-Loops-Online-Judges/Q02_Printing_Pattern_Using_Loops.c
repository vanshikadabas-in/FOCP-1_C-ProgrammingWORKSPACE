/* HackerRank Printing Pattern Using Loops (Pattern 2): concentric square.
   For n=2 output: 222 / 212 / 222. */
#include <stdio.h>
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; int size=2*n-1; for(int i=0;i<size;i++){for(int j=0;j<size;j++){int a=i< size-1-i?i:size-1-i; int b=j< size-1-j?j:size-1-j; int layer=a<b?a:b; printf("%d",n-layer); if(j<size-1)putchar(' ');} putchar('\n');} return 0; }

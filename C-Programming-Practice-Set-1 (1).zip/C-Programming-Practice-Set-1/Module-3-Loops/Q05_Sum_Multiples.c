/* LeetCode 2652: sum integers <= n divisible by 3, 5, or 7. */
#include <stdio.h>
int sumOfMultiples(int n) { int s=0; for(int i=1;i<=n;i++)if(i%3==0||i%5==0||i%7==0)s+=i; return s; }
#ifndef ONLINE_JUDGE
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; printf("%d\n",sumOfMultiples(n)); return 0; }
#endif

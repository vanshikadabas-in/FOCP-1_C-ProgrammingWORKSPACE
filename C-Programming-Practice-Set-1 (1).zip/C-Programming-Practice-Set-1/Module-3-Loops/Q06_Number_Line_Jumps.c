/* HackerRank Kangaroo / Number Line Jumps. */
#include <stdio.h>
int main(void) {
    long long x1,v1,x2,v2; if(scanf("%lld%lld%lld%lld",&x1,&v1,&x2,&v2)!=4)return 0;
    if(v1==v2) puts(x1==x2?"YES":"NO");
    else if((x2-x1)%(v1-v2)==0 && (x2-x1)/(v1-v2)>=0) puts("YES"); else puts("NO");
    return 0;
}

/* LeetCode 1342. */
#include <stdio.h>
int numberOfSteps(int num) { int steps=0; while(num>0) { if(num%2==0)num/=2; else num--; steps++; } return steps; }
#ifndef ONLINE_JUDGE
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; printf("%d\n",numberOfSteps(n)); return 0; }
#endif

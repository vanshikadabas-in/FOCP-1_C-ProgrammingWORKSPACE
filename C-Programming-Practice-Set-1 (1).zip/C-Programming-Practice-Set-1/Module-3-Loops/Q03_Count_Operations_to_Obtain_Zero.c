/* LeetCode 2169. */
#include <stdio.h>
int countOperations(int num1,int num2) { int c=0; while(num1 && num2) { if(num1>=num2)num1-=num2; else num2-=num1; c++; } return c; }
#ifndef ONLINE_JUDGE
int main(void) { int a,b; if(scanf("%d%d",&a,&b)!=2)return 0; printf("%d\n",countOperations(a,b)); return 0; }
#endif

/* LeetCode 1523. Count odds in inclusive [low, high]. */
#include <stdio.h>
int countOdds(int low,int high) { return (high+1)/2 - low/2; }
#ifndef ONLINE_JUDGE
int main(void) { int l,h; if(scanf("%d%d",&l,&h)!=2)return 0; printf("%d\n",countOdds(l,h)); return 0; }
#endif

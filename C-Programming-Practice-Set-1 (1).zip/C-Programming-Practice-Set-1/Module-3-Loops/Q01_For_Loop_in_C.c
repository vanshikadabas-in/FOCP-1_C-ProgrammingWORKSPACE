/* HackerRank For Loop in C: print number words for 1..9, then parity. */
#include <stdio.h>
int main(void) {
    int a,b; const char *words[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
    if(scanf("%d%d",&a,&b)!=2)return 0;
    for(int n=a;n<=b;n++) { if(n>=1 && n<=9) puts(words[n]); else puts(n%2==0?"even":"odd"); }
    return 0;
}

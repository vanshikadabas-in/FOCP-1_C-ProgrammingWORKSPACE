/* LeetCode 1281. */
#include <stdio.h>
int subtractProductAndSum(int n) { int p=1,s=0; do { int d=n%10; p*=d; s+=d; n/=10; } while(n>0); return p-s; }
#ifndef ONLINE_JUDGE
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; printf("%d\n",subtractProductAndSum(n)); return 0; }
#endif

/* LeetCode 7. Return 0 if the reversed value overflows signed 32-bit int. */
#include <stdio.h>
int reverse(int x) { long long r=0; while(x!=0){r=r*10+x%10; x/=10; if(r>2147483647LL||r< -2147483648LL)return 0;} return (int)r; }
#ifndef ONLINE_JUDGE
int main(void) { int x; if(scanf("%d",&x)!=1)return 0; printf("%d\n",reverse(x)); return 0; }
#endif

/* LeetCode 9. Negative numbers are not palindromes. */
#include <stdio.h>
#include <stdbool.h>
bool isPalindrome(int x) { if(x<0)return false; int original=x; long long rev=0; while(x>0){rev=rev*10+x%10;x/=10;} return rev==original; }
#ifndef ONLINE_JUDGE
int main(void) { int x; if(scanf("%d",&x)!=1)return 0; puts(isPalindrome(x)?"true":"false"); return 0; }
#endif

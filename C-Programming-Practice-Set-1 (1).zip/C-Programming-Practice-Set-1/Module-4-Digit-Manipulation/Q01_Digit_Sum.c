/* HackerEarth Digit Sum: read one integer and print the sum of its digits.
   The linked page could not be fully read without login; this is the common
   single-number form. Verify the statement/input format in your account. */
#include <stdio.h>
int main(void) { long long n; int s=0; if(scanf("%lld",&n)!=1)return 0; if(n<0)n=-n; do { s+=(int)(n%10); n/=10; } while(n>0); printf("%d\n",s); return 0; }

/* HackerRank Find Digits: count non-zero digits that divide n. */
#include <stdio.h>
int main(void) { int t; if(scanf("%d",&t)!=1)return 0; while(t--) { int n,x,c=0; scanf("%d",&n); x=n; while(x>0) { int d=x%10; if(d!=0 && n%d==0)c++; x/=10; } printf("%d\n",c); } return 0; }

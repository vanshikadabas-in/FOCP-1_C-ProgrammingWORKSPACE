/* LeetCode 2520. Zero digits are ignored to avoid division by zero. */
#include <stdio.h>
int countDigits(int num) { int x=num,c=0; while(x>0) { int d=x%10; if(d!=0 && num%d==0)c++; x/=10; } return c; }
#ifndef ONLINE_JUDGE
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; printf("%d\n",countDigits(n)); return 0; }
#endif

/* HackerEarth: Factorial!
   Input: one integer N (1 <= N <= 10).
   Output: N! on one line. */
#include <stdio.h>

int main(void) {
    int n;
    if (scanf("%d", &n) != 1) return 0;

    int factorial = 1;
    for (int i = 2; i <= n; i++) {
        factorial *= i;
    }

    printf("%d\n", factorial);
    return 0;
}

/* HackerEarth Prime Numbers: this starter interpretation reads T, then T
   integers N and prints all primes from 2 through each N on one line.
   Confirm this format against the linked statement before submission. */
#include <stdio.h>
int isPrime(int n){if(n<2)return 0;for(int i=2;i<=n/i;i++)if(n%i==0)return 0;return 1;}
int main(void) { int t,n; if(scanf("%d",&t)!=1)return 0; while(t--){scanf("%d",&n); int first=1; for(int x=2;x<=n;x++)if(isPrime(x)){if(!first)putchar(' ');printf("%d",x);first=0;} putchar('\n');} return 0; }

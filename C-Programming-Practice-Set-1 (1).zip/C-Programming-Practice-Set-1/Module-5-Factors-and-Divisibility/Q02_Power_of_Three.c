/* LeetCode 326. */
#include <stdio.h>
#include <stdbool.h>
bool isPowerOfThree(int n) { if(n<1)return false; while(n%3==0)n/=3; return n==1; }
#ifndef ONLINE_JUDGE
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; puts(isPowerOfThree(n)?"true":"false"); return 0; }
#endif

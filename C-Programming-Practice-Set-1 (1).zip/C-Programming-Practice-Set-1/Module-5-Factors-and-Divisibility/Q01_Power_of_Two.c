/* LeetCode 231. */
#include <stdio.h>
#include <stdbool.h>
bool isPowerOfTwo(int n) { return n>0 && (n&(n-1))==0; }
#ifndef ONLINE_JUDGE
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; puts(isPowerOfTwo(n)?"true":"false"); return 0; }
#endif

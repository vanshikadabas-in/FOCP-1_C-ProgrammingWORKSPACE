/* HackerEarth: Count Divisors
   Input: three integers L, R and K.
   Output: count of integers in [L, R] divisible by K. */
#include <stdio.h>

int main(void) {
    int l, r, k;
    if (scanf("%d %d %d", &l, &r, &k) != 3) return 0;

    /* Multiples of K up to R minus multiples before L. */
    int answer = r / k - (l - 1) / k;
    printf("%d\n", answer);
    return 0;
}

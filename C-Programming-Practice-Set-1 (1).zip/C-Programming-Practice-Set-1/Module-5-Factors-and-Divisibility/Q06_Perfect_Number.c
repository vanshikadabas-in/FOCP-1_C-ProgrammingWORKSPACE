/* LeetCode 507. */
#include <stdio.h>
#include <stdbool.h>
bool checkPerfectNumber(int num) { if(num<=1)return false; int sum=1; for(int i=2;i<=num/i;i++)if(num%i==0){sum+=i;if(i!=num/i)sum+=num/i;} return sum==num; }
#ifndef ONLINE_JUDGE
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; puts(checkPerfectNumber(n)?"true":"false"); return 0; }
#endif

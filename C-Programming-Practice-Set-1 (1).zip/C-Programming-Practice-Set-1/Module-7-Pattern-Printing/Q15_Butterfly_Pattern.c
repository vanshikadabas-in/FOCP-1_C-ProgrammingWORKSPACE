/* Print a Butterfly Pattern | Module 7, Set 1 */
#include <stdio.h>
int main(void) {
    int n;
    scanf("%d", &n);

    /* Upper half, including the widest row. */
    for (int i = 1; i <= (n + 1) / 2; i++) {
        for (int j = 1; j <= i; j++) printf("*");
        for (int s = 1; s <= 2 * (n - i) + 1; s++) printf(" ");
        for (int j = 1; j <= i; j++) printf("*");
        printf("\n");
    }

    /* Lower half mirrors the upper half without repeating the middle row. */
    for (int i = (n - 1) / 2; i >= 1; i--) {
        for (int j = 1; j <= i; j++) printf("*");
        for (int s = 1; s <= 2 * (n - i) + 1; s++) printf(" ");
        for (int j = 1; j <= i; j++) printf("*");
        printf("\n");
    }
    return 0;
}

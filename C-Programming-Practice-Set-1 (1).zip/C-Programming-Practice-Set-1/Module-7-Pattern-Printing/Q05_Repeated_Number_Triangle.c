/* Print a Repeated-Number Triangle | Module 7, Set 1 */
#include <stdio.h>
int main(void) {
    int n;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            if (j > 1) printf(" ");
            printf("%d", i);
        }
        printf("\n");
    }
    return 0;
}

/* LeetCode 2651. Submit findDelayedArrivalTime() on LeetCode. */
#include <stdio.h>
int findDelayedArrivalTime(int arrivalTime, int delayedTime) { return (arrivalTime + delayedTime) % 24; }
#ifndef ONLINE_JUDGE
int main(void) { int a,d; if(scanf("%d%d",&a,&d)!=2)return 0; printf("%d\n",findDelayedArrivalTime(a,d)); return 0; }
#endif

/* LeetCode 2739. Each 5 L used from main tank adds 1 L from reserve. */
#include <stdio.h>
int distanceTraveled(int mainTank, int additionalTank) {
    int distance=0, used=0;
    while(mainTank>0) {
        mainTank--; used++; distance+=10;
        if(used==5 && additionalTank>0) { mainTank++; additionalTank--; used=0; }
    }
    return distance;
}
#ifndef ONLINE_JUDGE
int main(void) { int m,a; if(scanf("%d%d",&m,&a)!=2)return 0; printf("%d\n",distanceTraveled(m,a)); return 0; }
#endif

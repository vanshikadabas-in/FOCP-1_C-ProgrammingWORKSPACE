/* HackerEarth: Read from STDIN, Write to STDOUT
   Input: integer N, then a string S. Output: N*2, then S. */
#include <stdio.h>
int main(void) {
    int n; char s[100005];
    if (scanf("%d %100004s", &n, s) != 2) return 0;
    printf("%d\n%s\n", n * 2, s);
    return 0;
}

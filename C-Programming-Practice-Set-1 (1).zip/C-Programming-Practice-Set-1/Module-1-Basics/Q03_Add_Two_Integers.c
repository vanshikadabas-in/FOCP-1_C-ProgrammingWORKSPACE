/* LeetCode 2235. Submit the function sum() on LeetCode.
   The main() below is only for local VS Code testing. */
#include <stdio.h>
int sum(int num1, int num2) { return num1 + num2; }
#ifndef ONLINE_JUDGE
int main(void) { int a,b; if(scanf("%d%d",&a,&b)!=2)return 0; printf("%d\n",sum(a,b)); return 0; }
#endif

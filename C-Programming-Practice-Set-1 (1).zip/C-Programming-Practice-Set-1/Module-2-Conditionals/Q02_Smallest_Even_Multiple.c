/* LeetCode 2413. Submit smallestEvenMultiple() on LeetCode. */
#include <stdio.h>
int smallestEvenMultiple(int n) { return (n%2==0)?n:2*n; }
#ifndef ONLINE_JUDGE
int main(void) { int n; if(scanf("%d",&n)!=1)return 0; printf("%d\n",smallestEvenMultiple(n)); return 0; }
#endif

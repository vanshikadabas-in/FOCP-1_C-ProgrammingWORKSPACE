/* HackerRank: FizzBuzz
   The linked challenge asks for the fixed sequence from 1 through 100.
   Print Fizz for multiples of 3, Buzz for multiples of 5, and FizzBuzz
   for multiples of both. There is no input. */
#include <stdio.h>

int main(void) {
    for (int i = 1; i <= 100; i++) {
        if (i % 15 == 0) {
            puts("FizzBuzz");
        } else if (i % 3 == 0) {
            puts("Fizz");
        } else if (i % 5 == 0) {
            puts("Buzz");
        } else {
            printf("%d\n", i);
        }
    }
    return 0;
}

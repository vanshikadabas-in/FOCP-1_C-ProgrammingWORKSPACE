/* HackerRank: print number words for 1..9, otherwise Greater than 9. */
#include <stdio.h>
int main(void) {
    int n; const char *words[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
    if(scanf("%d",&n)!=1)return 0;
    if(n>=1 && n<=9) puts(words[n]); else puts("Greater than 9");
    return 0;
}

/* HackerRank Grading Students: round up when grade >=38 and next multiple
   of 5 is less than 3 points away. */
#include <stdio.h>
int main(void) {
    int t,g; if(scanf("%d",&t)!=1)return 0;
    while(t--) { scanf("%d",&g); int next=((g/5)+1)*5; if(g>=38 && next-g<3)g=next; printf("%d\n",g); }
    return 0;
}

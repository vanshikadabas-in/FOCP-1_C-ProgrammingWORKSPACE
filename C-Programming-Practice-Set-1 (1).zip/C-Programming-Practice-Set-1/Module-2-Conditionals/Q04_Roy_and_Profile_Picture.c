/* HackerEarth Roy and Profile Picture.
   Input: minimum side L, number of photos N, then N pairs W H. */
#include <stdio.h>
int main(void) {
    int l,n,w,h; if(scanf("%d%d",&l,&n)!=2)return 0;
    while(n--) { scanf("%d%d",&w,&h); if(w<l || h<l) puts("UPLOAD ANOTHER"); else if(w==h) puts("ACCEPTED"); else puts("CROP IT"); }
    return 0;
}
